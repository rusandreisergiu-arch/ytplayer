package com.example.ytplayer

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class VideoItem(val title: String, val uploader: String, val url: String)

object YouTubeRepo {
    private val yt get() = ServiceList.YouTube

    fun init() = NewPipe.init(NewPipeDownloader, Localization("ro", "RO"))

    suspend fun search(query: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val handler = yt.searchQHFactory.fromQuery(query, listOf("videos"), "")
        SearchInfo.getInfo(yt, handler).relatedItems
            .filterIsInstance<StreamInfoItem>()
            .map { VideoItem(it.name, it.uploaderName ?: "", it.url) }
    }

    /** Returnează un MediaItem cu streamul video (max 720p, cu sunet) sau doar audio. */
    suspend fun resolve(video: VideoItem, audioOnly: Boolean): MediaItem =
        withContext(Dispatchers.IO) {
            val info = StreamInfo.getInfo(yt, video.url)
            val streamUrl = if (audioOnly) {
                info.audioStreams.maxByOrNull { it.averageBitrate }?.content
            } else {
                info.videoStreams.filter { it.height <= 720 }
                    .maxByOrNull { it.height }?.content
                    ?: info.audioStreams.maxByOrNull { it.averageBitrate }?.content
            } ?: error("Nu am găsit niciun stream redabil")
            MediaItem.Builder()
                .setUri(streamUrl)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(info.name)
                        .setArtist(info.uploaderName)
                        .build()
                )
                .build()
        }
}
