package com.example.ytplayer

import android.Manifest
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        // Nu eliberăm serviciul: doar ne deconectăm; redarea continuă în fundal.
        controller?.release()
        controller = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        val scope = rememberCoroutineScope()
        var query by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
        var audioOnly by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("") }

        val permission = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
            controller?.let { c ->
                AndroidView(
                    factory = { ctx -> PlayerView(ctx).apply { player = c } },
                    update = { it.player = c },
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Caută") }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    scope.launch {
                        status = "Se caută…"
                        runCatching { YouTubeRepo.search(query) }
                            .onSuccess { results = it; status = "" }
                            .onFailure { status = "Eroare: ${it.message}" }
                    }
                }) { Text("OK") }
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked = audioOnly, onCheckedChange = { audioOnly = it })
                Spacer(Modifier.width(8.dp))
                Text("Doar audio")
            }
            if (status.isNotEmpty()) Text(status)
            LazyColumn {
                items(results) { v ->
                    Column(
                        Modifier.fillMaxWidth().clickable {
                            scope.launch {
                                status = "Se încarcă…"
                                runCatching { YouTubeRepo.resolve(v, audioOnly) }
                                    .onSuccess { item ->
                                        controller?.run {
                                            setMediaItem(item); prepare(); play()
                                        }
                                        status = ""
                                    }
                                    .onFailure { status = "Eroare: ${it.message}" }
                            }
                        }.padding(vertical = 10.dp)
                    ) {
                        Text(v.title, style = MaterialTheme.typography.bodyLarge)
                        Text(v.uploader, style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
