package com.example.ytplayer

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        YouTubeRepo.init()
    }
}
