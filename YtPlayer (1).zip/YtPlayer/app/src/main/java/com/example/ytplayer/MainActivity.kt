package com.example.ytplayer

import android.Manifest
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controller?.release()
        controller = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        val scope = rememberCoroutineScope()
        val store = remember { HistoryStore(this) }
        var query by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
        var history by remember { mutableStateOf(store.load()) }
        var tab by remember { mutableIntStateOf(0) }
        var audioOnly by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("") }
        var nowPlaying by remember { mutableStateOf("") }

        val permission = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        fun play(v: VideoItem) {
            scope.launch {
                status = "Se încarcă…"
                runCatching { YouTubeRepo.resolve(v, audioOnly) }
                    .onSuccess { item ->
                        controller?.run { setMediaItem(item); prepare(); play() }
                        nowPlaying = v.title
                        history = store.add(v)
                        status = ""
                    }
                    .onFailure { status = "Eroare: ${it.message}" }
            }
        }

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
            controller?.let { c ->
                AndroidView(
                    factory = { ctx -> PlayerView(ctx).apply { player = c } },
                    update = { it.player = c },
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
            }
            if (nowPlaying.isNotEmpty()) {
                Text("▶ $nowPlaying", style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(vertical = 6.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Caută") }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    tab = 0
                    scope.launch {
                        status = "Se caută…"
                        runCatching { YouTubeRepo.search(query) }
                            .onSuccess { results = it; status = "" }
                            .onFailure { status = "Eroare: ${it.message}" }
                    }
                }) { Text("OK") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = audioOnly, onCheckedChange = { audioOnly = it })
                Spacer(Modifier.width(8.dp))
                Text("Doar audio")
            }
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Căutare") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Istoric") })
            }
            if (status.isNotEmpty()) Text(status, modifier = Modifier.padding(vertical = 6.dp))
            if (tab == 1 && history.isNotEmpty()) {
                TextButton(onClick = { store.clear(); history = emptyList() }) {
                    Text("Șterge istoricul")
                }
            }
            LazyColumn {
                items(if (tab == 0) results else history) { v ->
                    Column(
                        Modifier.fillMaxWidth().clickable { play(v) }.padding(vertical = 10.dp)
                    ) {
                        Text(v.title, style = MaterialTheme.typography.bodyLarge)
                        Text(v.uploader, style = MaterialTheme.typography.bodySmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
