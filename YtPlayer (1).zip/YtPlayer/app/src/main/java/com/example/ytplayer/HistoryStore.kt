package com.example.ytplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Istoric local: ce ai redat, ținut pe telefon (SharedPreferences). */
class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<VideoItem> {
        val arr = JSONArray(prefs.getString("items", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            VideoItem(o.getString("t"), o.getString("u"), o.getString("l"))
        }
    }

    fun add(v: VideoItem): List<VideoItem> {
        val list = (listOf(v) + load().filter { it.url != v.url }).take(100)
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("t", it.title).put("u", it.uploader).put("l", it.url))
        }
        prefs.edit().putString("items", arr.toString()).apply()
        return list
    }

    fun clear() = prefs.edit().remove("items").apply()
}
